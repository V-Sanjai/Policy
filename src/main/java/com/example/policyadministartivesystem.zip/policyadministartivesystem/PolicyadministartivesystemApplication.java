package com.example.policyadministartivesystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PolicyadministartivesystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(PolicyadministartivesystemApplication.class, args);
    }

}
