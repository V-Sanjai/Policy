package com.example.policyadministartivesystem.controller;

import com.example.policyadministartivesystem.entity.CoverageDetails;
import com.example.policyadministartivesystem.entity.CustomerDetails;
import com.example.policyadministartivesystem.entity.CustomerLocation;
import com.example.policyadministartivesystem.services.CoverageDetailsServiceImple;
import com.example.policyadministartivesystem.services.CustomerDetailsServiceImple;
import com.example.policyadministartivesystem.services.CustomerLocationServiceImple;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/")
public class CustomerDetailsController {

    @Autowired
    private CustomerDetailsServiceImple customerDetailsServiceImple;
    @Autowired
    private CustomerLocationServiceImple customerLocationServiceImple;
    @Autowired
    private CoverageDetailsServiceImple coverageDetailsServiceImple;

    @GetMapping("index")
    public String index() {
        return "index";
    }

    @GetMapping("addholder")
    public String addholder(Model model) {
        model.addAttribute("details", new CustomerDetails());
        model.addAttribute("locations", customerLocationServiceImple.getalllocation());
        model.addAttribute("coverages", coverageDetailsServiceImple.getallcoveragedetails());
        return "addholder";
    }


    @PostMapping("/submit")
    public String submit(@ModelAttribute("details") CustomerDetails customerDetails, @RequestParam("locations") List<Integer> id, @RequestParam("coverages") List<Integer> cid) {
        List<CustomerLocation> locations = new ArrayList<>();
        for (Integer locationId : id) {
            CustomerLocation location = customerLocationServiceImple.findbyid(locationId);
            locations.add(location);
        }
        customerDetails.setCustomerLocations(locations);

        List<CoverageDetails> coverageDetails = new ArrayList<>();
        for (Integer coverageId : cid) {
            CoverageDetails details = coverageDetailsServiceImple.findbyid(coverageId);
            coverageDetails.add(details);
        }
        customerDetails.setCoverageDetails(coverageDetails);
        customerDetailsServiceImple.add(customerDetails);
        return "list";
    }

    @GetMapping("/list")
    public String list(Model model) {
        List<CustomerDetails> customerDetailsList = customerDetailsServiceImple.getall();
        model.addAttribute("details", customerDetailsList);
        return "list";
    }


}
