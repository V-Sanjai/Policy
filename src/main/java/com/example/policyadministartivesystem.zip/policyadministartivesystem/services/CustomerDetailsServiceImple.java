package com.example.policyadministartivesystem.services;

import com.example.policyadministartivesystem.entity.CustomerDetails;
import com.example.policyadministartivesystem.repository.CustomerDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CustomerDetailsServiceImple implements CustomerDetailsService{

    @Autowired
    CustomerDetailsRepository customerDetailsRepository;
    @Override
    public List<CustomerDetails> getall() {
        return customerDetailsRepository.findAll();
    }

    @Override
    public CustomerDetails add(CustomerDetails customerDetails) {
        return customerDetailsRepository.save(customerDetails);
    }

    @Override
    public CustomerDetails findbyid(int id) {
        return customerDetailsRepository.findById(id).orElse(null);
    }

    @Override
    public void deletebyid(int id) {
        customerDetailsRepository.deleteById(id);
    }

    @Override
    public CustomerDetails update(CustomerDetails customerDetails) {
        return customerDetailsRepository.save(customerDetails);
    }
}
