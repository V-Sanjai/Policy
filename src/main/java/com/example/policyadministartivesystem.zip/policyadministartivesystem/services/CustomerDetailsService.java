package com.example.policyadministartivesystem.services;

import com.example.policyadministartivesystem.entity.CustomerDetails;

import java.util.List;

public interface CustomerDetailsService {
    public List<CustomerDetails> getall();
    public CustomerDetails add(CustomerDetails customerDetails);
    public CustomerDetails findbyid(int id);
    public void deletebyid(int id);

    public CustomerDetails update(CustomerDetails customerDetails);

}
