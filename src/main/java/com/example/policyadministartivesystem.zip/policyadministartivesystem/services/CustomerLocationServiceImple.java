package com.example.policyadministartivesystem.services;

import com.example.policyadministartivesystem.entity.CustomerLocation;
import com.example.policyadministartivesystem.repository.CustomerLocationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CustomerLocationServiceImple implements CustomerLocationService{

    @Autowired
   CustomerLocationRepository customerLocationRepository;
    @Override
    public List<CustomerLocation> getalllocation() {
        return customerLocationRepository.findAll();
    }

    @Override
    public CustomerLocation findbyid(int id) {
        return customerLocationRepository.findById(id).orElse(null);
    }
}
