package com.example.policyadministartivesystem.services;

import com.example.policyadministartivesystem.entity.CustomerLocation;

import java.util.List;

public interface CustomerLocationService {
    public List<CustomerLocation> getalllocation();
    public CustomerLocation findbyid(int id);
}
