package com.example.policyadministartivesystem.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;

import java.util.List;

@Entity
public class CustomerLocation {
    @Id

    private int id;
    private String state;


    @ManyToMany
    List<CustomerDetails> customerDetailsList;

    public CustomerLocation() {
    }

    public CustomerLocation(int id, String state) {
        this.id = id;
        this.state = state;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public List<CustomerDetails> getCustomerDetailsList() {
        return customerDetailsList;
    }

    public void setCustomerDetailsList(List<CustomerDetails> customerDetailsList) {
        this.customerDetailsList = customerDetailsList;
    }

    @Override
    public String toString() {
        return "CustomerLocation{" +
                "id=" + id +
                ", state='" + state + '\'' +
                '}';
    }
}
